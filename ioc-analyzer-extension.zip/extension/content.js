// IOC Analyzer — Content Script
// Listens for messages from popup to scan page text

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'scan_page') {
    const text = document.body.innerText || '';
    const iocs = extractIOCs(text);
    sendResponse({ iocs });
  }
  return true;
});

function extractIOCs(text) {
  const found = new Set();
  const patterns = [
    { re: /\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b/g, type: 'ip' },
    { re: /\b([a-f0-9]{64})\b/gi, type: 'sha256' },
    { re: /\b([a-f0-9]{40})\b/gi, type: 'sha1' },
    { re: /\b([a-f0-9]{32})\b/gi, type: 'md5' },
    { re: /\bhttps?:\/\/[^\s<>"']+/gi, type: 'url' },
    { re: /\b([a-z0-9][a-z0-9\-]{0,61}[a-z0-9]?\.[a-z]{2,})\b/gi, type: 'domain' },
    { re: /\bCVE-\d{4}-\d+\b/gi, type: 'cve' },
  ];
  const results = [];
  patterns.forEach(({ re, type }) => {
    let m;
    while ((m = re.exec(text)) !== null) {
      const val = m[0];
      if (!found.has(val) && val.length > 3) {
        found.add(val);
        results.push({ value: val, type });
        if (results.length >= 200) return;
      }
    }
  });
  return results;
}
