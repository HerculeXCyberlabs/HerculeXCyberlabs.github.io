// ================================================================
// IOC ANALYZER — Background Service Worker
// Handles: IndexedDB, API queries, cache, IOC import
// ================================================================

const DB_NAME = 'ioc_analyzer_db';
const DB_VER  = 2;
const CACHE_TTL = 6 * 60 * 60 * 1000; // 6 hours

// ---- DB HELPERS ----
function openDB() {
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB_NAME, DB_VER);
    r.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('ioc_feed')) {
        const s = db.createObjectStore('ioc_feed', { keyPath: 'id', autoIncrement: true });
        s.createIndex('value', 'value', { unique: false });
        s.createIndex('type',  'type',  { unique: false });
        s.createIndex('severity', 'severity', { unique: false });
      }
      if (!db.objectStoreNames.contains('api_cache')) {
        const c = db.createObjectStore('api_cache', { keyPath: 'key' });
        c.createIndex('expiry', 'expiry', { unique: false });
      }
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains('history')) {
        const h = db.createObjectStore('history', { keyPath: 'id', autoIncrement: true });
        h.createIndex('ts', 'ts', { unique: false });
      }
    };
    r.onsuccess = e => res(e.target.result);
    r.onerror   = e => rej(e.target.error);
  });
}

async function dbGet(store, key) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(store, 'readonly');
    tx.objectStore(store).get(key).onsuccess = e => res(e.target.result);
    tx.onerror = e => rej(e.target.error);
  });
}

async function dbPut(store, val) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(store, 'readwrite');
    tx.objectStore(store).put(val).onsuccess = e => res(e.target.result);
    tx.onerror = e => rej(e.target.error);
  });
}

async function dbGetAll(store) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(store, 'readonly');
    tx.objectStore(store).getAll().onsuccess = e => res(e.target.result);
    tx.onerror = () => res([]);
  });
}

async function dbCount(store) {
  const db = await openDB();
  return new Promise(res => {
    const tx = db.transaction(store, 'readonly');
    tx.objectStore(store).count().onsuccess = e => res(e.target.result);
    tx.onerror = () => res(0);
  });
}

async function dbClear(store) {
  const db = await openDB();
  return new Promise(res => {
    const tx = db.transaction(store, 'readwrite');
    tx.objectStore(store).clear().onsuccess = () => res();
    tx.onerror = () => res();
  });
}

async function dbSearchByIndex(store, indexName, value) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(store, 'readonly');
    const idx = tx.objectStore(store).index(indexName);
    idx.getAll(value).onsuccess = e => res(e.target.result);
    tx.onerror = () => res([]);
  });
}

// ---- IOC TYPE DETECTION ----
function detectType(v) {
  v = v.trim();
  if (/^[a-f0-9]{32}$/i.test(v))  return 'md5';
  if (/^[a-f0-9]{40}$/i.test(v))  return 'sha1';
  if (/^[a-f0-9]{64}$/i.test(v))  return 'sha256';
  if (/^(\d{1,3}\.){3}\d{1,3}(\/\d+)?$/.test(v)) return 'ip';
  if (/^https?:\/\//i.test(v))     return 'url';
  if (/^[a-z0-9][a-z0-9\-\.]{0,253}\.[a-z]{2,}$/i.test(v)) return 'domain';
  if (/^CVE-\d{4}-\d+$/i.test(v)) return 'cve';
  return 'unknown';
}

// ---- API CACHE ----
async function getCached(key) {
  const e = await dbGet('api_cache', key);
  if (!e || Date.now() > e.expiry) return null;
  return e.data;
}
async function setCache(key, data) {
  await dbPut('api_cache', { key, data, expiry: Date.now() + CACHE_TTL, ts: Date.now() });
}

// ---- VIRUSTOTAL ----
async function queryVT(ioc, type, apiKey) {
  if (!apiKey) return { source: 'VirusTotal', error: 'No API key configured', available: false };
  const ck = 'vt:' + ioc;
  const cached = await getCached(ck);
  if (cached) return { ...cached, cached: true };

  let ep = '';
  if (type === 'ip')     ep = `https://www.virustotal.com/api/v3/ip_addresses/${encodeURIComponent(ioc)}`;
  else if (type === 'domain') ep = `https://www.virustotal.com/api/v3/domains/${encodeURIComponent(ioc)}`;
  else if (type === 'url') ep = `https://www.virustotal.com/api/v3/urls/${btoa(ioc).replace(/=/g,'')}`;
  else if (['md5','sha1','sha256'].includes(type)) ep = `https://www.virustotal.com/api/v3/files/${ioc}`;
  else return { source: 'VirusTotal', error: 'Unsupported type', available: false };

  try {
    const r = await fetch(ep, { headers: { 'x-apikey': apiKey } });
    if (!r.ok) return { source: 'VirusTotal', error: `HTTP ${r.status}`, available: false };
    const j = await r.json();
    const a = j.data?.attributes || {};
    const s = a.last_analysis_stats || {};
    const result = {
      source: 'VirusTotal', available: true,
      malicious: s.malicious || 0, suspicious: s.suspicious || 0,
      harmless:  s.harmless  || 0, undetected: s.undetected  || 0,
      total: Object.values(s).reduce((x,y) => x+y, 0),
      reputation: a.reputation, country: a.country,
      asn: a.asn, asOwner: a.as_owner,
      categories: a.categories ? Object.values(a.categories).slice(0,3).join(', ') : '',
      tags: (a.tags || []).slice(0,5).join(', '),
      lastAnalysis: a.last_analysis_date ? new Date(a.last_analysis_date * 1000).toISOString().slice(0,10) : '',
      vtLink: `https://www.virustotal.com/gui/${type==='ip'?'ip-address':type==='md5'||type==='sha1'||type==='sha256'?'file':type}/${ioc}`,
    };
    await setCache(ck, result);
    return result;
  } catch(e) {
    return { source: 'VirusTotal', error: e.message, available: false };
  }
}

// ---- ABUSEIPDB ----
async function queryAbuseIPDB(ip, apiKey) {
  if (!apiKey) return { source: 'AbuseIPDB', error: 'No API key configured', available: false };
  const ck = 'abuse:' + ip;
  const cached = await getCached(ck);
  if (cached) return { ...cached, cached: true };

  try {
    const r = await fetch(`https://api.abuseipdb.com/api/v2/check?ipAddress=${encodeURIComponent(ip)}&maxAgeInDays=90&verbose`, {
      headers: { 'Key': apiKey, 'Accept': 'application/json' }
    });
    if (!r.ok) return { source: 'AbuseIPDB', error: `HTTP ${r.status}`, available: false };
    const j = await r.json();
    const d = j.data || {};
    const result = {
      source: 'AbuseIPDB', available: true,
      abuseScore: d.abuseConfidenceScore || 0,
      totalReports: d.totalReports || 0,
      country: d.countryCode, isp: d.isp, domain: d.domain,
      isWhitelisted: d.isWhitelisted,
      usageType: d.usageType,
      lastReported: d.lastReportedAt ? d.lastReportedAt.slice(0,10) : '',
      abuseLink: `https://www.abuseipdb.com/check/${ip}`,
    };
    await setCache(ck, result);
    return result;
  } catch(e) {
    return { source: 'AbuseIPDB', error: e.message, available: false };
  }
}

// ---- OTX ALIENVAULT ----
async function queryOTX(ioc, type, apiKey) {
  const ck = 'otx:' + ioc;
  const cached = await getCached(ck);
  if (cached) return { ...cached, cached: true };

  let section = '';
  if (type === 'ip') section = `IPv4/${ioc}/general`;
  else if (type === 'domain') section = `domain/${ioc}/general`;
  else if (type === 'url') section = `url/${encodeURIComponent(ioc)}/general`;
  else if (['md5','sha1','sha256'].includes(type)) section = `file/${ioc}/general`;
  else return { source: 'OTX AlienVault', error: 'Unsupported type', available: false };

  const headers = apiKey ? { 'X-OTX-API-KEY': apiKey } : {};
  try {
    const r = await fetch(`https://otx.alienvault.com/api/v1/indicators/${section}`, { headers });
    if (!r.ok) return { source: 'OTX AlienVault', error: `HTTP ${r.status}`, available: false };
    const j = await r.json();
    const result = {
      source: 'OTX AlienVault', available: true,
      pulseCount: j.pulse_info?.count || 0,
      pulses: (j.pulse_info?.pulses || []).slice(0,3).map(p => p.name),
      country: j.country_name,
      reputation: j.reputation,
      tags: (j.tags || []).slice(0,5),
      malwareFamily: j.malware_families ? j.malware_families.slice(0,3).map(m=>m.display_name).join(', ') : '',
      otxLink: `https://otx.alienvault.com/indicator/${type==='ip'?'ip':type}/${ioc}`,
    };
    await setCache(ck, result);
    return result;
  } catch(e) {
    return { source: 'OTX AlienVault', error: e.message, available: false };
  }
}

// ---- URLHAUS (free, no key needed) ----
async function queryURLhaus(ioc, type) {
  if (!['url','domain','ip'].includes(type)) return null;
  const ck = 'urlhaus:' + ioc;
  const cached = await getCached(ck);
  if (cached) return { ...cached, cached: true };

  try {
    const body = type === 'url' ? `url=${encodeURIComponent(ioc)}` : `host=${encodeURIComponent(ioc)}`;
    const r = await fetch(`https://urlhaus-api.abuse.ch/v1/${type==='url'?'url':'host'}/`, {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body
    });
    if (!r.ok) return null;
    const j = await r.json();
    if (j.query_status === 'no_results') return { source: 'URLhaus', available: true, found: false };
    const result = {
      source: 'URLhaus', available: true, found: true,
      urlCount: j.urls_count || (j.urls || []).length,
      threat: j.threat || (j.urls && j.urls[0]?.threat) || '',
      tags: j.tags || [],
      dateAdded: j.date_added || '',
    };
    await setCache(ck, result);
    return result;
  } catch(e) { return null; }
}

// ---- THREATFOX (free, no key needed) ----
async function queryThreatFox(ioc) {
  const ck = 'tf:' + ioc;
  const cached = await getCached(ck);
  if (cached) return { ...cached, cached: true };

  try {
    const r = await fetch('https://threatfox-api.abuse.ch/api/v1/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: 'search_ioc', search_term: ioc })
    });
    if (!r.ok) return null;
    const j = await r.json();
    if (j.query_status !== 'ok' || !j.data) return { source: 'ThreatFox', available: true, found: false };
    const d = j.data[0] || {};
    const result = {
      source: 'ThreatFox', available: true, found: true,
      malware: d.malware_printable || '',
      malwareFamily: d.malware || '',
      threatType: d.threat_type || '',
      confidence: d.confidence_level || 0,
      tags: d.tags || [],
      firstSeen: d.first_seen ? d.first_seen.slice(0,10) : '',
    };
    await setCache(ck, result);
    return result;
  } catch(e) { return null; }
}

// ---- FEODO TRACKER (free, no key) ----
async function queryFeodo(ip) {
  const ck = 'feodo:' + ip;
  const cached = await getCached(ck);
  if (cached) return { ...cached, cached: true };

  try {
    const r = await fetch('https://feodotracker.abuse.ch/downloads/ipblocklist.json');
    if (!r.ok) return null;
    const j = await r.json();
    const found = j.find(e => e.ip_address === ip);
    const result = found
      ? { source: 'Feodo Tracker', available: true, found: true, malware: found.malware, status: found.status, country: found.country }
      : { source: 'Feodo Tracker', available: true, found: false };
    await setCache(ck, result);
    return result;
  } catch(e) { return null; }
}

// ---- OFFLINE SEARCH ----
async function searchOffline(ioc) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction('ioc_feed', 'readonly');
    const idx = tx.objectStore('ioc_feed').index('value');
    // Use cursor for partial match
    const results = [];
    const lower = ioc.toLowerCase();
    tx.objectStore('ioc_feed').openCursor().onsuccess = e => {
      const cursor = e.target.result;
      if (cursor) {
        const rec = cursor.value;
        if (rec.value && rec.value.toLowerCase().includes(lower)) results.push(rec);
        if (results.length < 100) cursor.continue();
        else res(results);
      } else {
        res(results);
      }
    };
    tx.onerror = () => res([]);
  });
}

// ---- COMBINED LOOKUP ----
async function analyzIOC(ioc) {
  ioc = ioc.trim();
  const type = detectType(ioc);

  // Get settings
  const vtKey    = (await dbGet('settings', 'vt_key'))?.value    || '';
  const abuseKey = (await dbGet('settings', 'abuse_key'))?.value || '';
  const otxKey   = (await dbGet('settings', 'otx_key'))?.value   || '';

  // Always check offline first
  const offlineHits = await searchOffline(ioc);

  // Check online connectivity
  let online = false;
  try { await fetch('https://www.google.com/favicon.ico', { method: 'HEAD', mode: 'no-cors' }); online = true; } catch(e) {}

  const sources = [];

  if (online) {
    // Run all applicable sources in parallel
    const promises = [];
    if (vtKey) promises.push(queryVT(ioc, type, vtKey));
    else promises.push(Promise.resolve({ source: 'VirusTotal', error: 'No API key', available: false }));

    if (type === 'ip') {
      if (abuseKey) promises.push(queryAbuseIPDB(ioc, abuseKey));
      else promises.push(Promise.resolve({ source: 'AbuseIPDB', error: 'No API key', available: false }));
      promises.push(queryFeodo(ioc));
    }

    promises.push(queryOTX(ioc, type, otxKey));
    if (['url','domain','ip'].includes(type)) promises.push(queryURLhaus(ioc, type));
    promises.push(queryThreatFox(ioc));

    const results = await Promise.allSettled(promises);
    results.forEach(r => { if (r.status === 'fulfilled' && r.value) sources.push(r.value); });
  }

  // Score calculation
  let score = 0, verdict = 'UNKNOWN', color = 'grey';
  const vtRes = sources.find(s => s.source === 'VirusTotal');
  const abRes = sources.find(s => s.source === 'AbuseIPDB');
  const otxRes = sources.find(s => s.source === 'OTX AlienVault');
  const tfRes  = sources.find(s => s.source === 'ThreatFox');

  if (vtRes?.available)  score += Math.min(50, (vtRes.malicious || 0) * 5);
  if (abRes?.available)  score += Math.round((abRes.abuseScore || 0) * 0.4);
  if (otxRes?.available) score += Math.min(20, (otxRes.pulseCount || 0) * 2);
  if (tfRes?.found)      score += 20;
  if (offlineHits.length > 0) score = Math.max(score, 60);

  score = Math.min(100, score);
  if (score >= 75)      { verdict = 'MALICIOUS';   color = 'red';    }
  else if (score >= 40) { verdict = 'SUSPICIOUS';  color = 'orange'; }
  else if (score >= 10) { verdict = 'LOW RISK';    color = 'yellow'; }
  else if (online || offlineHits.length > 0) { verdict = 'CLEAN'; color = 'green'; }

  // Save to history
  await dbPut('history', {
    ts: Date.now(), ioc, type, verdict, score, online,
    offlineHits: offlineHits.length, sources: sources.map(s=>s.source)
  });

  return { ioc, type, verdict, score, color, online, sources, offlineHits, ts: Date.now() };
}

// ---- IOC IMPORT ----
async function importIOCFile(content, filename, format) {
  const records = [];
  const lines = content.split(/\r?\n/).map(l => l.trim()).filter(l => l && !l.startsWith('#'));

  if (format === 'json' || filename.endsWith('.json')) {
    try {
      const j = JSON.parse(content);
      const arr = Array.isArray(j) ? j : (j.iocs || j.indicators || j.data || []);
      arr.forEach(item => {
        const v = item.value || item.indicator || item.ip || item.domain || item.hash || item.ioc || '';
        if (v) records.push({
          value: v.trim(), type: detectType(v.trim()),
          severity: item.severity || item.confidence || 'medium',
          source: item.source || item.feed || filename,
          tags: Array.isArray(item.tags) ? item.tags.join(',') : (item.tags||''),
          description: item.description || item.name || '',
          ts: Date.now()
        });
      });
    } catch(e) {}
  } else if (filename.endsWith('.stix') || filename.endsWith('.xml')) {
    // Basic STIX 2.x JSON or STIX 1.x XML parsing
    try {
      const j = JSON.parse(content);
      const objects = j.objects || [];
      objects.filter(o => o.type === 'indicator').forEach(ind => {
        const pattern = ind.pattern || '';
        const m = pattern.match(/value\s*=\s*'([^']+)'/);
        if (m) records.push({
          value: m[1], type: detectType(m[1]),
          severity: 'high', source: filename,
          tags: (ind.labels||[]).join(','),
          description: ind.name || '', ts: Date.now()
        });
      });
    } catch(e) {}
  } else {
    // CSV or plain text — one IOC per line or CSV
    const isCSV = content.includes(',') && lines[0].includes(',');
    let headers = [];
    let startIdx = 0;
    if (isCSV) {
      headers = lines[0].toLowerCase().split(',').map(h => h.trim().replace(/"/g,''));
      startIdx = 1;
    }
    for (let i = startIdx; i < lines.length; i++) {
      let v = '', sev = 'medium', src = filename, tags = '', desc = '';
      if (isCSV && headers.length > 0) {
        const cols = lines[i].split(',').map(c => c.trim().replace(/"/g,''));
        const vi = headers.findIndex(h => ['ioc','value','indicator','ip','domain','hash','url'].includes(h));
        v = vi >= 0 ? cols[vi] : cols[0];
        const si = headers.findIndex(h => ['severity','confidence','risk'].includes(h));
        if (si >= 0) sev = cols[si] || 'medium';
        const ti = headers.findIndex(h => h === 'tags' || h === 'tag');
        if (ti >= 0) tags = cols[ti] || '';
        const di = headers.findIndex(h => ['description','name','details'].includes(h));
        if (di >= 0) desc = cols[di] || '';
      } else {
        v = lines[i].split(/[\s,\t]/)[0];
      }
      if (v && detectType(v) !== 'unknown') {
        records.push({ value: v.trim(), type: detectType(v.trim()), severity: sev, source: src, tags, description: desc, ts: Date.now() });
      }
    }
  }

  // Bulk insert
  const db = await openDB();
  let inserted = 0;
  return new Promise(res => {
    const tx = db.transaction('ioc_feed', 'readwrite');
    const store = tx.objectStore('ioc_feed');
    records.forEach(r => { store.put(r); inserted++; });
    tx.oncomplete = () => res(inserted);
    tx.onerror = () => res(inserted);
  });
}

// ----------------------------------------------------------------
// MESSAGE HANDLER
// ----------------------------------------------------------------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg.action === 'analyze') {
        const result = await analyzIOC(msg.ioc);
        sendResponse({ ok: true, result });
      } else if (msg.action === 'analyze_bulk') {
        const iocs = msg.iocs.slice(0, 50); // max 50 at once
        const results = [];
        for (const ioc of iocs) {
          results.push(await analyzIOC(ioc));
        }
        sendResponse({ ok: true, results });
      } else if (msg.action === 'import_feed') {
        const count = await importIOCFile(msg.content, msg.filename, msg.format);
        sendResponse({ ok: true, count });
      } else if (msg.action === 'get_stats') {
        const feedCount  = await dbCount('ioc_feed');
        const cacheCount = await dbCount('api_cache');
        const histCount  = await dbCount('history');
        const vtKey    = (await dbGet('settings', 'vt_key'))?.value    || '';
        const abuseKey = (await dbGet('settings', 'abuse_key'))?.value || '';
        const otxKey   = (await dbGet('settings', 'otx_key'))?.value   || '';
        sendResponse({ ok: true, feedCount, cacheCount, histCount, vtKey: !!vtKey, abuseKey: !!abuseKey, otxKey: !!otxKey });
      } else if (msg.action === 'save_settings') {
        if (msg.vt_key   !== undefined) await dbPut('settings', { key: 'vt_key',    value: msg.vt_key   });
        if (msg.abuse_key !== undefined) await dbPut('settings', { key: 'abuse_key', value: msg.abuse_key });
        if (msg.otx_key  !== undefined) await dbPut('settings', { key: 'otx_key',   value: msg.otx_key  });
        sendResponse({ ok: true });
      } else if (msg.action === 'get_history') {
        const h = await dbGetAll('history');
        sendResponse({ ok: true, history: h.sort((a,b) => b.ts - a.ts).slice(0, 100) });
      } else if (msg.action === 'search_feed') {
        const hits = await searchOffline(msg.query);
        sendResponse({ ok: true, hits });
      } else if (msg.action === 'clear_feed') {
        await dbClear('ioc_feed');
        sendResponse({ ok: true });
      } else if (msg.action === 'clear_cache') {
        await dbClear('api_cache');
        sendResponse({ ok: true });
      } else if (msg.action === 'get_feed_sample') {
        const db = await openDB();
        const recs = await new Promise(res => {
          const tx = db.transaction('ioc_feed', 'readonly');
          const results = [];
          tx.objectStore('ioc_feed').openCursor(null, 'prev').onsuccess = e => {
            const c = e.target.result;
            if (c && results.length < 200) { results.push(c.value); c.continue(); }
            else res(results);
          };
          tx.onerror = () => res([]);
        });
        sendResponse({ ok: true, records: recs });
      } else {
        sendResponse({ ok: false, error: 'Unknown action' });
      }
    } catch(e) {
      sendResponse({ ok: false, error: e.message });
    }
  })();
  return true; // async
});

// Context menu — right click on selected text to analyze
chrome.contextMenus.create({
  id: 'analyze_ioc',
  title: 'Analyze as IOC',
  contexts: ['selection']
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'analyze_ioc') {
    chrome.storage.local.set({ pendingIOC: info.selectionText });
    chrome.action.openPopup();
  }
});
